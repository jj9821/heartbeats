/**
 * Authentication Context Provider
 *
 * Wraps the app to provide:
 * - Current Firebase user state
 * - User's Firestore profile
 * - Loading state during auth check
 * - Sign in / sign out functions
 *
 * On first login, creates a Firestore user profile and requests
 * notification permission + FCM token.
 */

"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import { onAuthStateChanged, User } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { signInWithGoogle, signOutUser } from "@/lib/auth";
import {
  getUserProfile,
  createUserProfile,
  updateOnlineStatus,
} from "@/lib/firestore";
import { requestAndSaveFCMToken } from "@/lib/messaging";
import { UserProfile } from "@/types";

interface AuthContextValue {
  /** Firebase Auth user (null if not signed in) */
  user: User | null;
  /** Firestore user profile (null if not loaded or not signed in) */
  profile: UserProfile | null;
  /** True while checking auth state on initial load */
  loading: boolean;
  /** Sign in with Google popup */
  signIn: () => Promise<void>;
  /** Sign out */
  signOut: () => Promise<void>;
  /** Refresh profile from Firestore */
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  profile: null,
  loading: true,
  signIn: async () => {},
  signOut: async () => {},
  refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Load or create Firestore profile for authenticated user
  const loadProfile = async (firebaseUser: User) => {
    let userProfile = await getUserProfile(firebaseUser.uid);

    if (!userProfile) {
      // First-time user — create Firestore profile
      userProfile = await createUserProfile(
        firebaseUser.uid,
        firebaseUser.displayName || "User",
        firebaseUser.email || "",
        firebaseUser.photoURL || ""
      );
    }

    setProfile(userProfile);

    // Mark user as online
    await updateOnlineStatus(firebaseUser.uid, true);

    // Request push notification permission and save FCM token
    try {
      await requestAndSaveFCMToken(firebaseUser.uid);
    } catch (err) {
      console.warn("Could not get FCM token:", err);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      const p = await getUserProfile(user.uid);
      setProfile(p);
    }
  };

  // Listen to Firebase auth state changes
  useEffect(() => {
    if (!auth) {
      console.error("Firebase Auth is not initialized. Please verify your .env.local file.");
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      try {
        setUser(firebaseUser);
        if (firebaseUser) {
          await loadProfile(firebaseUser);
        } else {
          setProfile(null);
        }
      } catch (err) {
        console.error("Auth state change callback error:", err);
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Track online/offline status via browser visibility API
  useEffect(() => {
    if (!user) return;

    const handleVisibilityChange = () => {
      updateOnlineStatus(user.uid, !document.hidden);
    };

    const handleBeforeUnload = () => {
      updateOnlineStatus(user.uid, false);
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [user]);

  const signIn = async () => {
    try {
      await signInWithGoogle();
    } catch (err) {
      console.error("Sign in error:", err);
    }
  };

  const signOut = async () => {
    if (user) {
      await updateOnlineStatus(user.uid, false);
    }
    await signOutUser();
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, signIn, signOut, refreshProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

/** Hook to access auth state from any component */
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
