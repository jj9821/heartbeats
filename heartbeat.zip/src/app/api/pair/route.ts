/**
 * API Route: Pair two users
 *
 * POST /api/pair
 * Body: { inviteCode: string }
 *
 * Looks up the user by invite code, validates, and pairs both users.
 */

import { NextRequest, NextResponse } from "next/server";
import { getAdminDb } from "@/lib/firebase-admin";

export async function POST(request: NextRequest) {
  try {
    const { inviteCode } = await request.json();

    if (!inviteCode || inviteCode.length !== 6) {
      return NextResponse.json(
        { success: false, error: "Invalid invite code" },
        { status: 400 }
      );
    }

    const adminDb = getAdminDb();

    // Get the current user's UID from the request header
    const authHeader = request.headers.get("x-user-uid");

    // Find user with this invite code
    const snapshot = await adminDb
      .collection("users")
      .where("inviteCode", "==", inviteCode.toUpperCase())
      .limit(1)
      .get();

    if (snapshot.empty) {
      return NextResponse.json(
        { success: false, error: "No user found with this code" },
        { status: 404 }
      );
    }

    const partnerDoc = snapshot.docs[0];
    const partnerData = partnerDoc.data();

    // Can't pair with yourself
    if (authHeader && partnerDoc.id === authHeader) {
      return NextResponse.json(
        { success: false, error: "You can't pair with yourself!" },
        { status: 400 }
      );
    }

    // Check if partner is already paired
    if (partnerData.partnerId) {
      return NextResponse.json(
        { success: false, error: "This person is already paired with someone" },
        { status: 400 }
      );
    }

    // Pair both users atomically
    const batch = adminDb.batch();

    if (authHeader) {
      // Check if current user is already paired
      const currentUserDoc = await adminDb.collection("users").doc(authHeader).get();
      if (currentUserDoc.exists && currentUserDoc.data()?.partnerId) {
        return NextResponse.json(
          { success: false, error: "You are already paired with someone" },
          { status: 400 }
        );
      }

      batch.update(adminDb.collection("users").doc(authHeader), {
        partnerId: partnerDoc.id,
      });
    }

    batch.update(adminDb.collection("users").doc(partnerDoc.id), {
      partnerId: authHeader || null,
    });

    await batch.commit();

    return NextResponse.json({
      success: true,
      partnerName: partnerData.name,
    });
  } catch (error) {
    console.error("Pairing error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to pair" },
      { status: 500 }
    );
  }
}
