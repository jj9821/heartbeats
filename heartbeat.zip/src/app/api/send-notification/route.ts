/**
 * API Route: Send Push Notification
 *
 * POST /api/send-notification
 *
 * Sends an FCM push notification to the partner device.
 * Checks quiet hours before sending.
 */

import { NextRequest, NextResponse } from "next/server";
import { getAdminDb, getAdminMessaging } from "@/lib/firebase-admin";
import { isInQuietHours } from "@/lib/utils";

export async function POST(request: NextRequest) {
  try {
    const { receiverId, senderName, message } = await request.json();

    if (!receiverId || !senderName) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Get receiver's profile from Firestore
    const adminDb = getAdminDb();
    const receiverDoc = await adminDb.collection("users").doc(receiverId).get();
    if (!receiverDoc.exists) {
      return NextResponse.json(
        { success: false, error: "Receiver not found" },
        { status: 404 }
      );
    }

    const receiver = receiverDoc.data();
    if (!receiver) {
      return NextResponse.json(
        { success: false, error: "Receiver data empty" },
        { status: 404 }
      );
    }

    // Check if notifications are enabled
    if (receiver.settings?.notificationsEnabled === false) {
      return NextResponse.json({ success: true }); // Silently succeed
    }

    // Check quiet hours (server-side suppression)
    if (
      receiver.settings?.quietHoursEnabled &&
      isInQuietHours(
        receiver.settings.quietHoursStart || "22:00",
        receiver.settings.quietHoursEnd || "07:00"
      )
    ) {
      return NextResponse.json({ success: true }); // Silently succeed
    }

    // Get FCM token
    const fcmToken = receiver.fcmToken;
    if (!fcmToken) {
      return NextResponse.json({ success: true }); // No token, silently succeed
    }

    // Send FCM notification
    await getAdminMessaging().send({
      token: fcmToken,
      notification: {
        title: "❤️ Someone misses you",
        body: `${senderName} is thinking about you.${message ? ` "${message}"` : ""}`,
      },
      webpush: {
        fcmOptions: { link: "/" },
        notification: {
          icon: "/icons/icon-192x192.png",
          badge: "/icons/icon-192x192.png",
          vibrate: [200, 100, 200],
          requireInteraction: false,
        },
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Send notification error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to send notification" },
      { status: 500 }
    );
  }
}
