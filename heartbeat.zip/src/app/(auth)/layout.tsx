/**
 * Auth-protected Layout
 *
 * Wraps all authenticated pages with:
 * - Auth guard (redirects to / if not signed in)
 * - Redirect to /pair if user has no partner
 * - Bottom navigation bar
 * - Foreground notification listener
 * - Page content area with safe padding
 */

"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { BottomNav } from "@/components/BottomNav";
import { Spinner } from "@/components/ui/Spinner";
import { onForegroundMessage } from "@/lib/messaging";
import { toast } from "sonner";
import { Heart } from "lucide-react";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, profile, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);

  // Auth guard
  useEffect(() => {
    if (loading) return;

    if (!user) {
      router.replace("/");
      return;
    }

    // If no partner and not on pair page, redirect to pair
    if (profile && !profile.partnerId && pathname !== "/pair") {
      router.replace("/pair");
      return;
    }

    setReady(true);
  }, [user, profile, loading, pathname, router]);

  // Listen for foreground notifications (show toast)
  useEffect(() => {
    const unsubscribe = onForegroundMessage((payload) => {
      toast(payload.title, {
        description: payload.body,
        icon: <Heart className="w-5 h-5 text-pink-500 fill-pink-500" />,
        duration: 5000,
      });
    });

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  if (loading || !ready) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-dvh">
        <div className="flex flex-col items-center gap-4">
          <Spinner size="lg" />
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Loading your heartbeat...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-dvh">
      <main className="flex-1 pb-20 safe-area-top">{children}</main>
      {/* Show bottom nav only if user is paired */}
      {profile?.partnerId && <BottomNav />}
    </div>
  );
}
