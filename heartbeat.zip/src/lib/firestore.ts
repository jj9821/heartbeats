/**
 * Firestore CRUD Operations
 *
 * All database reads and writes are centralized here for:
 * - User profiles
 * - Signal creation and querying
 * - Partner pairing
 * - Online status tracking
 */

import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  addDoc,
  serverTimestamp,
  getDocs,
  Timestamp,
  writeBatch,
} from "firebase/firestore";
import { db } from "./firebase";
import {
  UserProfile,
  Signal,
  CreateSignalData,
  UserSettings,
  DEFAULT_USER_SETTINGS,
} from "@/types";
import { generateInviteCode } from "./utils";

// =============================================================================
// User Operations
// =============================================================================

/**
 * Get a user profile by UID.
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? (snap.data() as UserProfile) : null;
}

/**
 * Create a new user profile after first Google Sign-In.
 * Generates a unique invite code for partner pairing.
 */
export async function createUserProfile(
  uid: string,
  name: string,
  email: string,
  photo: string
): Promise<UserProfile> {
  const profile: UserProfile = {
    uid,
    name,
    email,
    photo,
    partnerId: null,
    fcmToken: null,
    inviteCode: generateInviteCode(),
    createdAt: Timestamp.now(),
    lastSeen: Timestamp.now(),
    online: true,
    settings: DEFAULT_USER_SETTINGS,
  };
  await setDoc(doc(db, "users", uid), profile);
  return profile;
}

/**
 * Update specific fields on a user profile.
 */
export async function updateUserProfile(
  uid: string,
  data: Partial<UserProfile>
): Promise<void> {
  await updateDoc(doc(db, "users", uid), data);
}

/**
 * Update user settings.
 */
export async function updateUserSettings(
  uid: string,
  settings: Partial<UserSettings>
): Promise<void> {
  const userRef = doc(db, "users", uid);
  const snap = await getDoc(userRef);
  if (snap.exists()) {
    const current = snap.data() as UserProfile;
    await updateDoc(userRef, {
      settings: { ...current.settings, ...settings },
    });
  }
}

/**
 * Find a user by their invite code (for pairing).
 */
export async function findUserByInviteCode(
  code: string
): Promise<UserProfile | null> {
  const q = query(
    collection(db, "users"),
    where("inviteCode", "==", code.toUpperCase()),
    limit(1)
  );
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return snap.docs[0].data() as UserProfile;
}

/**
 * Pair two users together using a batch write for atomicity.
 */
export async function pairUsers(
  userId: string,
  partnerId: string
): Promise<void> {
  const batch = writeBatch(db);
  batch.update(doc(db, "users", userId), { partnerId });
  batch.update(doc(db, "users", partnerId), { partnerId: userId });
  await batch.commit();
}

/**
 * Unpair two users (disconnect).
 */
export async function unpairUsers(
  userId: string,
  partnerId: string
): Promise<void> {
  const batch = writeBatch(db);
  batch.update(doc(db, "users", userId), { partnerId: null });
  batch.update(doc(db, "users", partnerId), { partnerId: null });
  await batch.commit();
}

/**
 * Update online/offline status and lastSeen timestamp.
 */
export async function updateOnlineStatus(
  uid: string,
  online: boolean
): Promise<void> {
  await updateDoc(doc(db, "users", uid), {
    online,
    lastSeen: serverTimestamp(),
  });
}

/**
 * Subscribe to a user's real-time profile changes.
 * Returns an unsubscribe function.
 */
export function subscribeToUser(
  uid: string,
  callback: (user: UserProfile | null) => void
): () => void {
  return onSnapshot(doc(db, "users", uid), (snap) => {
    callback(snap.exists() ? (snap.data() as UserProfile) : null);
  });
}

// =============================================================================
// Signal Operations
// =============================================================================

/**
 * Create a new "miss" signal and save it to Firestore.
 * The timestamp is set server-side for consistency.
 */
export async function createSignal(data: CreateSignalData): Promise<string> {
  const docRef = await addDoc(collection(db, "signals"), {
    ...data,
    timestamp: serverTimestamp(),
  });
  return docRef.id;
}

/**
 * Subscribe to signals between two users (real-time).
 * Returns signals ordered by timestamp descending.
 */
export function subscribeToSignals(
  userId: string,
  partnerId: string,
  callback: (signals: Signal[]) => void,
  limitCount: number = 50
): () => void {
  // We query signals where user is either sender or receiver
  // Firestore doesn't support OR queries on different fields,
  // so we'll use two listeners and merge.
  const signals = new Map<string, Signal>();
  let sentLoaded = false;
  let receivedLoaded = false;

  const emitIfReady = () => {
    if (sentLoaded && receivedLoaded) {
      const all = Array.from(signals.values()).sort((a, b) => {
        const aTime = a.timestamp?.toMillis?.() || 0;
        const bTime = b.timestamp?.toMillis?.() || 0;
        return bTime - aTime;
      });
      callback(all);
    }
  };

  // Signals sent by the user to the partner
  const q1 = query(
    collection(db, "signals"),
    where("senderId", "==", userId),
    where("receiverId", "==", partnerId),
    orderBy("timestamp", "desc"),
    limit(limitCount)
  );

  // Signals received by the user from the partner
  const q2 = query(
    collection(db, "signals"),
    where("senderId", "==", partnerId),
    where("receiverId", "==", userId),
    orderBy("timestamp", "desc"),
    limit(limitCount)
  );

  const unsub1 = onSnapshot(q1, (snap) => {
    snap.docs.forEach((d) => signals.set(d.id, { id: d.id, ...d.data() } as Signal));
    sentLoaded = true;
    emitIfReady();
  });

  const unsub2 = onSnapshot(q2, (snap) => {
    snap.docs.forEach((d) => signals.set(d.id, { id: d.id, ...d.data() } as Signal));
    receivedLoaded = true;
    emitIfReady();
  });

  return () => {
    unsub1();
    unsub2();
  };
}

/**
 * Save FCM token to user profile for push notifications.
 */
export async function saveFCMToken(
  uid: string,
  token: string
): Promise<void> {
  await updateDoc(doc(db, "users", uid), { fcmToken: token });
}
