/**
 * Auth helper functions
 */

import { signInWithPopup, signOut as firebaseSignOut } from "firebase/auth";
import { auth, googleProvider } from "./firebase";

/**
 * Sign in with Google using a popup window.
 * Returns the Firebase User object on success.
 */
export async function signInWithGoogle() {
  return signInWithPopup(auth, googleProvider);
}

/**
 * Sign out the current user.
 */
export async function signOutUser() {
  return firebaseSignOut(auth);
}
