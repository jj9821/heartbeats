/**
 * Server-side Firebase Admin SDK Initialization
 *
 * Used in Next.js API routes for:
 * - Sending FCM push notifications
 * - Verifying auth tokens
 * - Server-side Firestore operations
 *
 * SETUP:
 * 1. Go to Firebase Console → Project Settings → Service Accounts
 * 2. Click "Generate new private key" to download a JSON file
 * 3. Copy the values to your .env.local (see .env.local.example)
 *
 * IMPORTANT: The private key contains newline characters (\n).
 * In .env.local, wrap it in double quotes so they are preserved.
 */

import { initializeApp, getApps, cert, type App } from "firebase-admin/app";
import { getFirestore, type Firestore } from "firebase-admin/firestore";
import { getMessaging, type Messaging } from "firebase-admin/messaging";

/**
 * Lazily initialize Firebase Admin to avoid build-time errors
 * when environment variables aren't set yet.
 */
function getAdminApp(): App {
  if (getApps().length > 0) {
    return getApps()[0];
  }

  const projectId = process.env.FIREBASE_ADMIN_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, "\n");

  if (!projectId || !clientEmail || !privateKey) {
    throw new Error(
      "Firebase Admin SDK credentials are missing. " +
      "Please set FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL, " +
      "and FIREBASE_ADMIN_PRIVATE_KEY in your .env.local file."
    );
  }

  return initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
  });
}

/** Server-side Firestore instance (lazy-initialized) */
export function getAdminDb(): Firestore {
  return getFirestore(getAdminApp());
}

/** Server-side FCM instance for sending push notifications (lazy-initialized) */
export function getAdminMessaging(): Messaging {
  return getMessaging(getAdminApp());
}
