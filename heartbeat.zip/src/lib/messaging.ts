/**
 * Firebase Cloud Messaging (FCM) — Client-side utilities
 *
 * Handles:
 * - Requesting notification permission from the browser
 * - Getting the FCM registration token
 * - Listening for foreground messages
 *
 * SETUP:
 * 1. Enable Cloud Messaging in Firebase Console
 * 2. Generate a VAPID key under Cloud Messaging → Web Push certificates
 * 3. Add the VAPID key to NEXT_PUBLIC_FIREBASE_VAPID_KEY in .env.local
 *
 * NOTE: Push notifications require HTTPS (localhost works for dev).
 * The service worker file (public/firebase-messaging-sw.js) handles
 * background notifications when the app is not in focus.
 */

import { getMessaging, getToken, onMessage } from "firebase/messaging";
import app from "./firebase";
import { saveFCMToken } from "./firestore";

/**
 * Get the FCM messaging instance. Only works in browser context.
 * Returns null during SSR.
 */
function getMessagingInstance() {
  if (typeof window === "undefined") return null;
  try {
    return getMessaging(app);
  } catch {
    console.warn("Firebase Messaging not supported in this browser");
    return null;
  }
}

/**
 * Request notification permission and get FCM token.
 * Saves the token to Firestore for the given user.
 *
 * @param uid - The authenticated user's UID
 * @returns The FCM token string, or null if permission denied
 */
export async function requestAndSaveFCMToken(
  uid: string
): Promise<string | null> {
  const messaging = getMessagingInstance();
  if (!messaging) return null;

  try {
    // Request browser notification permission
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      console.log("Notification permission denied");
      return null;
    }

    // Get FCM registration token using VAPID key
    const token = await getToken(messaging, {
      vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY,
    });

    if (token) {
      // Save token to Firestore so server can send to this device
      await saveFCMToken(uid, token);
      console.log("FCM token saved successfully");
      return token;
    }

    return null;
  } catch (error) {
    console.error("Error getting FCM token:", error);
    return null;
  }
}

/**
 * Listen for foreground messages (when app is open and focused).
 * Background messages are handled by the service worker.
 *
 * @param callback - Function to call with the notification payload
 * @returns Unsubscribe function
 */
export function onForegroundMessage(
  callback: (payload: { title: string; body: string }) => void
): (() => void) | null {
  const messaging = getMessagingInstance();
  if (!messaging) return null;

  return onMessage(messaging, (payload) => {
    console.log("Foreground message received:", payload);
    callback({
      title: payload.notification?.title || "❤️ Someone misses you",
      body: payload.notification?.body || "Someone is thinking about you.",
    });
  });
}
