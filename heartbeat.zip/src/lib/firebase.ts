/**
 * Client-side Firebase Initialization
 *
 * This module initializes Firebase for use in the browser. It uses a singleton
 * pattern to ensure only one Firebase app instance exists.
 *
 * SETUP:
 * 1. Create a Firebase project at https://console.firebase.google.com
 * 2. Enable Google Sign-In under Authentication → Sign-in method
 * 3. Create a Firestore database
 * 4. Copy your config values to .env.local (see .env.local.example)
 *
 * NOTE: Firebase initialization is deferred until the config is available.
 * During SSR/prerendering, the exports will be stubs that only work client-side.
 */

import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

// Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

/**
 * Get or create the Firebase app instance.
 * Returns null during SSR if config is missing.
 */
function getFirebaseApp(): FirebaseApp | null {
  if (!firebaseConfig.apiKey) return null;
  try {
    return getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  } catch {
    return null;
  }
}

// Lazy getters that only initialize when actually used in the browser
let _app: FirebaseApp | null = null;
let _auth: Auth | null = null;
let _db: Firestore | null = null;

function ensureApp(): FirebaseApp | null {
  if (!_app) {
    _app = getFirebaseApp();
  }
  return _app;
}

// Firebase services — these are accessed only client-side
export function getAppAuth(): Auth | null {
  if (!_auth) {
    const appInstance = ensureApp();
    if (appInstance) _auth = getAuth(appInstance);
  }
  return _auth;
}

export function getAppDb(): Firestore | null {
  if (!_db) {
    const appInstance = ensureApp();
    if (appInstance) _db = getFirestore(appInstance);
  }
  return _db;
}

// For backward compatibility, export as getters
export const auth = typeof window !== "undefined" ? getAppAuth() as Auth : (null as unknown as Auth);
export const db = typeof window !== "undefined" ? getAppDb() as Firestore : (null as unknown as Firestore);
export const googleProvider = new GoogleAuthProvider();

// Default export for messaging initialization
const app = typeof window !== "undefined" ? ensureApp() : null;
export default app;
